//
//  CoreDataStructures.c
//  Lisp Parser
//
//  Created by Jason Rymal on 1/24/13.
//  Copyright (c) 2013 Jason Rymal. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

#include "CoreDataStructures.h"

void push(Stack *stack, void *value) {
    (stack->size)++;
    stack->value = realloc(stack->value, stack->size * sizeof(void*));
    stack->value[stack->size - 1] = value;
}

void *pop(Stack *stack) {
    void *value = stack->value[stack->size - 1];
    (stack->size)--;
    return value;
}

void freeParseTree(ParseElement *root) {
   
    int i; 
    for(i = root->elementCount - 1; i >= 0; i--) {
        freeParseTree(&root->elements[i]);
    }
    
    free(root->elements);
    free(root->data);
}

void addToList(List **list, char *value) {

    if (value != NULL) {
        List *iter;

        if (list == NULL || *list == NULL) {
            iter = *list = malloc( sizeof(List) );
        } else {
            iter = *list; 
            while (iter->next != NULL) {
                iter = iter->next;
            }

            iter->next = malloc( sizeof(List) );
            iter = iter->next;
        }
    
        iter->value = value;
        iter->next = NULL;
    }
}

void printList(List *list) {
    List *iter = list;
    while (iter != NULL) {
        if (iter->value == NULL) {
            printf("SHIT ");
        } else {
            printf("%s ", (char*) iter->value);
        }
        iter = iter->next;
    }
    printf("\n");
}
